from pathlib import Path
from zipfile import ZipFile

with ZipFile("files/file.zip", "w") as zip:
    for path in Path("files").rglob("*.*"):  # *.* all files
        # validate not to zip this zip file
        # print(path)
        if str(path) != "files/file.zip":
            zip.write(path)
